# Raspberry Pi deployment bundle

Everything needed to run the IoMT intrusion-detection ensemble on a Raspberry Pi 4B, and nothing
else. No TensorFlow, no training code, no datasets — `TRD.md §7` puts only the inference graph on
the device.

## 1. Copy this directory to the Pi

```bash
scp -r pi_bundle/ pi@raspberrypi.local:~/iomt-ids
```

## 2. Install the two dependencies

```bash
cd ~/iomt-ids
python3 -m pip install -r requirements-pi.txt
```

If `tflite-runtime` has no wheel for your Python version, use `ai-edge-litert` instead — the
runner accepts either, and reports which one it used.

## 3. Check it loads

```bash
python3 pi_inference.py --model-dir deployment --self-test
```

Expected: `Self-test ... PASS`, `Raspberry Pi : True`, and `backend : tflite_runtime`.
If the backend says `tensorflow`, the standalone runtime is not installed and any timing you take
will not be a `tflite-runtime` measurement.

## 4. Prove it agrees with the evaluated model

```bash
python3 pi_inference.py --model-dir deployment \
    --input sample_windows.npy --expected expected.npy
```

`agreement with supplied labels` must read **100.0000%**. `expected.npy` holds the predictions the
development machine produced for the same 256 real test windows, so anything below
100% means the Pi is not reproducing the model this project evaluated — investigate before
believing any result from the device.

## 5. Benchmark (this is T4.3's deliverable)

```bash
python3 benchmark_pi.py --model-dir deployment --windows sample_windows.npy
```

Writes `reports/deployment_benchmark.md` with the measured latency percentiles, per-branch timings,
throughput, and the hardware read from the device tree. **On non-Pi hardware this refuses to run**
unless `--allow-non-pi` is passed, which produces a `DRAFT_` file stamped as not deployment
evidence.

Copy the resulting report and its `.json` back into the repository's `reports/`.

## What is in here

| File | Purpose |
|---|---|
| `pi_inference.py` | Standalone runner. Imports only numpy and a TFLite interpreter. |
| `benchmark.py` | Timing harness; refuses to write a deployment report off a Pi. |
| `benchmark_pi.py` | Command-line entry point for the benchmark. |
| `deployment/` | 3 `.tflite` graphs plus `manifest.json`. |
| `sample_windows.npy` | 256 real test windows, shape (n, 10, 62). |
| `expected.npy` | Reference predictions for those windows. |

## Model contract

- Input: `(10, 62)` — 10 consecutive flow records, features in the exact
  order given by `manifest.json`'s `feature_names`. A reordered column would corrupt every
  prediction undetectably.
- Output: 2 class probabilities. **Index 1 is `Attack` — the positive class**
  (`TRD.md §2.3`, deliberately the opposite of the base paper's convention). Any metric computed on
  the Pi must state this.
- Fusion: `w_b = alpha_b * (max_k p_b[k]) ** gamma / sum_b'; P = sum_b w_b * p_b` with gamma = 1.0.

## Not included, on purpose

Flow capture, feature extraction, and sessionisation. The bundle takes pre-built windows. An
end-to-end real-time claim needs the capture path measured too, which is outside this project's
scope — and the benchmark report says so rather than implying otherwise.
